# elastic-hover
Elastic hover using vanilla javascript and jQuery
